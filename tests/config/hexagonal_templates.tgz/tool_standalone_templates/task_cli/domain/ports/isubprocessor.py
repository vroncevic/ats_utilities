# -*- coding: UTF-8 -*-

'''
Module
    isubprocessor.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines abstract interface for sub-process execution.
'''

from abc import ABC, abstractmethod
from typing import Any

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


class ISubProcessor(ABC):
    '''
        Abstract interface for sub-process execution.

        It defines:

            :attributes: None.
            :methods:
                | run - Executes a sub-process.
    '''

    @abstractmethod
    def run(self, command: list[str], capture_output: bool = False, text: bool = True) -> dict[str, Any]:
        '''
            Runs a sub-process.

            :param command: The command to execute.
            :type command: <list[str]>
            :param capture_output: Whether to capture the output.
            :type capture_output: <bool>
            :param text: Whether to decode the output as text.
            :type text: <bool>
            :exceptions: None.   
        '''
        pass
