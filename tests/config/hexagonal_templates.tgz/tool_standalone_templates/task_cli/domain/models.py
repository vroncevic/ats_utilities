# -*- coding: UTF-8 -*-

'''
Module
    models.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines domain modes representing tool parameters.
'''

from dataclasses import dataclass

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


@dataclass
class Tool:
    '''
        Domain model representing a tool parameters.

        It defines:

            :attributes:
                | params - The list of parameters for the tool.
            :methods:
                | from_params - Factory method that constructs Tool with parameters.
    '''

    params: list[str]

    @classmethod
    def from_params(cls, params: list[str]) -> "Tool":
        '''
            Factory method that constructs Tool with parameters.

            :param params: Parameters for the tool.
            :type params: <list[str]>
            :return: The generated Tool domain model instance with tool parameters.
            :rtype: <Tool>
            :exceptions: ValueError - Tool parameters cannot be None.
        '''
        if not params:
            raise ValueError("tool parameters list must be provided.")

        return cls(params=params)
