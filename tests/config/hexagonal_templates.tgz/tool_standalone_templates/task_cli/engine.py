# -*- coding: UTF-8 -*-

'''
Module
    engine.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Main engine orchestrator class for Task Code tool CLI.
'''

from ${project_name}.i${project_name} import I${project_name_camel}
from ${project_name}.${project_name}_bundle import ${project_name_camel}Bundle
from ${project_name}.domain.ports.isubprocessor import ISubProcessor
from ${project_name}.infrastructure.subprocessor import SubProcessor
from ${project_name}.domain.ports.iservice import IService
from ${project_name}.application.service import Service
from ${project_name}.infrastructure.iarg_parser import IArgParser
from ${project_name}.infrastructure.arg_parser import ArgParser
from ${project_name}.infrastructure.icli_command import ICLICommand
from ${project_name}.infrastructure.ping_command import PingCommand
from ${project_name}.infrastructure.cli_bundle import CLIBundle
from ${project_name}.infrastructure.icli import ICLI
from ${project_name}.infrastructure.cli import CLI

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


class ${project_name_camel}(I${project_name_camel}):
    '''
        Engine orchestrating the initialization and execution of ${project_name_camel}.

        It defines:

            :attributes:
                | _is_initialized - Flag indicating if the ${project_name_camel} engine is initialized.
                | _cli - Adapter for command line user interface (primary adapter).
            :methods:
                | __init__ - Initializes the ${project_name_camel} engine with adapters and services.
                | is_initialized - Checks if the ${project_name_camel} engine is initialized.
                | run - Starts the CLI adapter to run the tool command.
    '''

    def __init__(self, component_bundle: ${project_name_camel}Bundle | None = None) -> None:
        '''
            Initializes the ${project_name_camel} engine with adapters and services.

            :param component_bundle: ${project_name_camel} bundle containing adapters and services | None.
            :type component_bundle: <${project_name_camel}Bundle | None>
            :exceptions: None.
        '''
        self._is_initialized: bool = False

        try:
            # Dependency injection: Dependency Inversion Principle
            # Use provided component bundle or use default adapters
            bundle: ${project_name_camel}Bundle = component_bundle or ${project_name_camel}Bundle()

            # Initialization of secondary adapter (Service)
            # Sub processor for execution of other tools/commands
            # Force default implementation of sub processor if not provided by bundle
            subprocessor: ISubProcessor = bundle.subprocessor or SubProcessor()

            # Injecting adapter into the application service (Orchestration)
            # Force default implementation of service if not provided by bundle
            service: IService = bundle.service or Service(subprocessor=subprocessor)

            # Initialization of primary adapter (Infrastructure)
            # Force default implementation of arg parser if not provided by bundle
            parser: IArgParser = bundle.parser or ArgParser(description="Task CLI")

            # Setting up CLI command strategies
            commands: list[ICLICommand] = [PingCommand()]

            # Setting up primary adapter (Infrastructure)
            # Force default implementation of CLI if not provided by bundle
            cli_bundle: CLIBundle = CLIBundle(service=service, parser=parser, commands=commands)
            self._cli: ICLI = bundle.cli or CLI(component_bundle=cli_bundle)

            # Mark as initialized
            self._is_initialized = True

        except (TypeError, ValueError) as exc:
            print(f"${project_name}: {exc}")
        except Exception as exc:
            print(f"${project_name} unexpected exception: {exc}")

    def is_initialized(self) -> bool:
        '''
            Checks if the ${project_name_camel} engine is initialized.

            :return: <True> if ${project_name_camel} is initialized, <False> otherwise.
            :rtype: <bool>
            :exceptions: None.
        '''
        return self._is_initialized

    def run(self) -> None:
        '''
            Starts the CLI adapter to run the tool command.

            :exceptions: None.
        '''
        if self.is_initialized():
            self._cli.run()
        else:
            print("${project_name}: engine is not initialized.")
