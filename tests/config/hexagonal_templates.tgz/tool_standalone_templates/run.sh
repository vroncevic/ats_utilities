#
# python3 main.py -h
# python3 main.py ping -h
#
python3 main.py ping --hostname localhost --count 2
