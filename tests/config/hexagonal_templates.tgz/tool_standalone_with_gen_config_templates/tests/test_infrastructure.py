# -*- coding: UTF-8 -*-

'''
Module
    test_infrastructure.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Unit tests for infrastructure adapters.
'''

import os
import tempfile
import unittest
from unittest.mock import patch, MagicMock
from ${project_name}.infrastructure.command_option import CommandOption
from ${project_name}.infrastructure.icli_command import ICLICommand
from ${project_name}.infrastructure.arg_parser import ArgParser
from ${project_name}.infrastructure.cli_bundle import CLIBundle
from ${project_name}.infrastructure.cli import CLI
from ${project_name}.infrastructure.file_writer import FileWriter
from ${project_name}.infrastructure.template_provider import TemplateProvider
from ${project_name}.infrastructure.gen_config_command import GenConfigCommand
from ${project_name}.infrastructure.gen_service_command import GenServiceCommand
from ${project_name}.domain.ports.ifile_gen import IFileGen

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


class DummyCommand(ICLICommand):
    '''
        Dummy CLI command for testing ArgParser.

        It defines:

            :attributes: None
            :methods:
                | name - Command name.
                | help_text - Command help text.
                | options - Command options.
                | execute - Simulates command execution.
    '''

    @property
    def name(self) -> str:
        '''
            Returns command name.

            :return: The command name.
            :rtype: <str>
            :exceptions: None.
        '''
        return "dummy"

    @property
    def help_text(self) -> str:
        '''
            Returns command help text.

            :return: The command help.
            :rtype: <str>
            :exceptions: None.
        '''
        return "Dummy command for tests"

    @property
    def options(self) -> list[CommandOption]:
        '''
            Returns command options.

            :return: List of command options.
            :rtype: <List[CommandOption]>
            :exceptions: None.
        '''
        return [
            CommandOption(name="--foo", help_text="foo parameter", default="bar"),
            CommandOption(name="--req", help_text="required parameter", required=True)
        ]

    def execute(self, params: dict, service: IFileGen) -> None:
        '''
            Simulates execution.

            :param params: Execution params.
            :type params: <dict>
            :param service: Generation service.
            :type service: <IFileGen>
            :exceptions: None.
        '''
        pass


class TestInfrastructure(unittest.TestCase):
    '''
        Defines infrastructure adapters unit tests.

        It defines:

            :attributes: None
            :methods:
                | test_arg_parser_success - Tests successful CLI argument parsing.
                | test_cli_bundle_validation - Tests validation checks of CLIBundle.
                | test_cli_run_executes_command - Tests that CLI.run executes matching command strategy.
                | test_gen_config_command_metadata - Tests GenConfigCommand properties.
                | test_gen_service_command_metadata - Tests GenServiceCommand properties.
                | test_cli_bundle_helpers - Tests CLIBundle helper methods.
                | test_cli_bundle_validate_commands_none - Tests CLIBundle validation with None commands.
                | test_cli_init_missing_bundle - Tests CLI init with None bundle.
                | test_concrete_file_writer - Tests concrete FileWriter.
                | test_concrete_template_provider - Tests concrete TemplateProvider.
    '''

    def test_arg_parser_success(self) -> None:
        '''
            Tests successful registration and parsing of CLI arguments.

            :exceptions: None.
        '''
        parser = ArgParser("Test CLI")
        cmd = DummyCommand()
        parser.register_commands([cmd])

        test_args = ["main.py", "dummy", "--req", "val", "--foo", "baz"]
        with patch("sys.argv", test_args):
            cmd_name, params = parser.parse()

        self.assertEqual(cmd_name, "dummy")
        self.assertEqual(params["req"], "val")
        self.assertEqual(params["foo"], "baz")

    def test_cli_bundle_validation(self) -> None:
        '''
            Tests validation checks of CLIBundle.

            :exceptions: None.
        '''
        bundle = CLIBundle(service=None, parser=None, commands=None)
        with self.assertRaises(ValueError):
            bundle.validate()

        bundle_partial = CLIBundle(service=MagicMock(), parser=None, commands=[])
        with self.assertRaises(ValueError):
            bundle_partial.validate()

    def test_cli_run_executes_command(self) -> None:
        '''
            Tests that CLI.run parses arguments and delegates execution to the matched command.

            :exceptions: None.
        '''
        mock_service = MagicMock(spec=IFileGen)
        mock_parser = MagicMock(spec=ArgParser)
        mock_command = MagicMock(spec=ICLICommand)
        mock_command.name = "dummy"

        mock_parser.parse.return_value = ("dummy", {"foo": "bar"})

        cli_bundle = CLIBundle(service=mock_service, parser=mock_parser, commands=[mock_command])
        cli = CLI(cli_bundle)
        cli.run()

        mock_parser.parse.assert_called_once()
        mock_command.execute.assert_called_once_with({"foo": "bar"}, mock_service)

    def test_gen_config_command_metadata(self) -> None:
        '''
            Tests GenConfigCommand properties and parameter mapping execution.

            :exceptions: None.
        '''
        cmd = GenConfigCommand()
        self.assertEqual(cmd.name, "generate-config")
        self.assertEqual(cmd.help_text, "Generate configuration file")
        self.assertEqual(len(cmd.options), 4)

        mock_service = MagicMock(spec=IFileGen)
        params = {"filename": "out.ini", "env": "dev", "app_name": "Test"}
        cmd.execute(params, mock_service)

        mock_service.generate.assert_called_once_with(
            template_name="config",
            target_filename="out.ini",
            cli_params={"env": "dev", "app_name": "Test", "debug_mode": "True"}
        )

    def test_gen_service_command_metadata(self) -> None:
        '''
            Tests GenServiceCommand properties and execution.

            :exceptions: None.
        '''
        cmd = GenServiceCommand()
        self.assertEqual(cmd.name, "generate-service")
        self.assertEqual(cmd.help_text, "Generate Python service class")
        self.assertEqual(len(cmd.options), 3)

        mock_service = MagicMock(spec=IFileGen)
        params = {"filename": "srv.py", "module_name": "Auth", "app_name": "Test"}
        cmd.execute(params, mock_service)

        mock_service.generate.assert_called_once_with(
            template_name="service",
            target_filename="srv.py",
            cli_params={"module_name": "Auth", "app_name": "Test"}
        )

    def test_cli_bundle_helpers(self) -> None:
        '''
            Tests CLIBundle helper methods (merge, to_dict).

            :exceptions: None.
        '''
        mock_service = MagicMock(spec=IFileGen)
        mock_parser = MagicMock(spec=ArgParser)

        bundle1 = CLIBundle(service=mock_service, parser=None, commands=None)
        bundle2 = CLIBundle(service=None, parser=mock_parser, commands=[])
        bundle1.merge(bundle2)

        self.assertEqual(bundle1.service, mock_service)
        self.assertEqual(bundle1.parser, mock_parser)
        self.assertEqual(bundle1.commands, [])

        d = bundle1.to_dict()
        self.assertEqual(d["service"], mock_service)
        self.assertEqual(d["parser"], mock_parser)
        self.assertEqual(d["commands"], [])

    def test_cli_bundle_validate_commands_none(self) -> None:
        '''
            Tests CLIBundle validate raises ValueError when commands list is None.

            :exceptions: None.
        '''
        bundle = CLIBundle(service=MagicMock(), parser=MagicMock(), commands=None)
        with self.assertRaises(ValueError):
            bundle.validate()

    def test_cli_init_missing_bundle(self) -> None:
        '''
            Tests CLI initialization raises ValueError when bundle is None.

            :exceptions: None.
        '''
        with self.assertRaises(ValueError):
            CLI(None)

    def test_concrete_file_writer(self) -> None:
        '''
            Tests concrete FileWriter.

            :exceptions: None.
        '''
        writer = FileWriter()
        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = os.path.join(tmpdir, "nested_dir", "test_file.txt")
            writer.write_file(file_path, "hello world")

            self.assertTrue(os.path.exists(file_path))
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
            self.assertEqual(content, "hello world")

    def test_concrete_template_provider(self) -> None:
        '''
            Tests concrete TemplateProvider.

            :exceptions: None.
        '''
        provider = TemplateProvider()
        self.assertTrue(os.path.exists(provider.templates_dir))

        config_template = provider.get_template_by_name("config")
        self.assertTrue(len(config_template) > 0)

        service_template = provider.get_template_by_name("service")
        self.assertTrue(len(service_template) > 0)

        with tempfile.TemporaryDirectory() as tmpdir:
            custom_provider = TemplateProvider(templates_dir=tmpdir)
            self.assertEqual(custom_provider.templates_dir, tmpdir)

            with self.assertRaises(FileNotFoundError):
                custom_provider.get_template_by_name("nonexistent")
