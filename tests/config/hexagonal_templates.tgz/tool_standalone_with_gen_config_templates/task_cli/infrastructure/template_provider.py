# -*- coding: UTF-8 -*-

'''
Module
    template_provider.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines template provider adapter that loads templates from files.
'''

from os.path import abspath, dirname, join, exists
from ${project_name}.domain.ports.itemplate_provider import ITemplateProvider

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


class TemplateProvider(ITemplateProvider):
    '''
        Adapter that reads templates from the filesystem.

        It defines:

            :attributes:
                | templates_dir - The directory where templates are stored.
            :methods:
                | get_template_by_name - Reads template content from file.
    '''

    def __init__(self, templates_dir: str | None = None):
        '''
            Initializes the TemplateProvider with a directory path.

            :param templates_dir: Path to directory containing templates.
            :type templates_dir: <str | None>
            :exceptions: None.
        '''
        # Defines the path to the internal 'templates' folder
        if templates_dir is None:
            current_dir = dirname(abspath(__file__))
            self.templates_dir = join(current_dir, "templates")
        else:
            self.templates_dir = templates_dir

    def get_template_by_name(self, name: str) -> str:
        '''
            Reads template content from file based on template name.

            :param name: The name of the template.
            :type name: <str>
            :return: The content of the template file.
            :rtype: <str>
            :exceptions: FileNotFoundError, OSError.
        '''
        file_path = join(self.templates_dir, f"{name}.template")

        if not exists(file_path):
            raise FileNotFoundError(f"Template {name} does not exist at path {file_path}")

        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()
