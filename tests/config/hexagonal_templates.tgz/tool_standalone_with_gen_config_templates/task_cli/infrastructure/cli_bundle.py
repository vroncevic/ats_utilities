# -*- coding: UTF-8 -*-

'''
Module
    cli_bundle.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines a CLIBundle bundle for the infrastructure adapters.
'''

from dataclasses import dataclass
from ${project_name}.domain.ports.ifile_gen import IFileGen
from ${project_name}.infrastructure.iarg_parser import IArgParser
from ${project_name}.infrastructure.icli_command import ICLICommand

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


@dataclass
class CLIBundle:
    '''
        Data class for CLI adapters bundle.

        It defines:

            :attributes:
                | service - Service orchestrating file generation (default None).
                | parser - Argument parser for parsing CLI command args (default None).
                | commands - List of command instances (default None).
            :methods:
                | validate - Validates that essential components are set.
                | merge - Merges non-None values from another bundle.
                | to_dict - Converts the bundle attributes to a dictionary.
    '''

    service: IFileGen | None = None
    parser: IArgParser | None = None
    commands: list[ICLICommand] | None = None

    def validate(self) -> None:
        '''
            Validates that essential components are set.

            :exceptions: ValueError.
                            | Service must be provided.
                            | Parser must be provided.
                            | List of commands must be provided.
        '''
        if self.service is None:
            raise ValueError("Service must be provided.")

        if self.parser is None:
            raise ValueError("Parser must be provided.")

        if self.commands is None:
            raise ValueError("List of commands must be provided.")

    def merge(self, other: 'CLIBundle') -> None:
        '''
            Merges non-None values from another bundle into this one.

            :param other: Another bundle to merge into this one.
            :type other: <CLIBundle>
            :exceptions: None.
        '''
        for field_name in self.__dataclass_fields__:
            other_value = getattr(other, field_name)
            if other_value is not None:
                setattr(self, field_name, other_value)

    def to_dict(self) -> dict:
        '''
            Converts the bundle attributes to a dictionary.

            :return: Dictionary representation of the bundle attributes.
            :rtype: <dict>
            :exceptions: None.
        '''
        return {
            name: value
            for name, value in self.__dict__.items()
            if not name.startswith('_')
        }
