# -*- coding: UTF-8 -*-

'''
Module
    engine.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Main engine orchestrator class for Task Code Generator CLI.
'''

from ${project_name}.i${project_name} import I${project_name_camel}
from ${project_name}.${project_name}_bundle import ${project_name_camel}Bundle
from ${project_name}.domain.ports.itemplate_provider import ITemplateProvider
from ${project_name}.infrastructure.template_provider import TemplateProvider
from ${project_name}.domain.ports.ifile_writer import IFileWriter
from ${project_name}.infrastructure.file_writer import FileWriter
from ${project_name}.application.service_bundle import ServiceBundle
from ${project_name}.domain.ports.ifile_gen import IFileGen
from ${project_name}.application.service import FileGen
from ${project_name}.infrastructure.arg_parser import ArgParser
from ${project_name}.infrastructure.cli_bundle import CLIBundle
from ${project_name}.infrastructure.icli import ICLI
from ${project_name}.infrastructure.cli import CLI
from ${project_name}.infrastructure.gen_config_command import GenConfigCommand

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


class ${project_name_camel}(I${project_name_camel}):
    '''
        Engine orchestrating the initialization and execution of ${project_name_camel}.

        It defines:

            :attributes:
                | template_provider - Adapter for reading templates.
                | file_writer - Adapter for writing files.
                | service - Service orchestrating file generation.
                | parser - Argument parser adapter.
                | _cli - Adapter for command line user interface.
                | _is_initialized - Flag indicating if the ${project_name_camel} engine is initialized.
            :methods:
                | __init__ - Initializes the ${project_name_camel} engine with adapters and services.
                | run - Starts the CLI program.
    '''

    def __init__(self, component_bundle: ${project_name_camel}Bundle | None = None) -> None:
        '''
            Initializes the ${project_name_camel} engine with adapters and services.

            :param component_bundle: ${project_name_camel} bundle containing adapters and services | None.
            :type component_bundle: <${project_name_camel}Bundle | None>
            :exceptions: None.
        '''
        self._is_initialized: bool = False

        try:
            # Dependency injection: Dependency Inversion Principle
            # Use provided component bundle or use default adapters
            bundle: ${project_name_camel}Bundle = component_bundle or ${project_name_camel}Bundle()

            # Initialization of secondary adapters (Infrastructure)
            template_provider: ITemplateProvider = bundle.template_provider or TemplateProvider()
            file_writer: IFileWriter = bundle.file_writer or FileWriter()
            parser: ArgParser = bundle.parser or ArgParser(description="Task CLI")

            # Injecting adapters into the application service (Orchestration)
            service_bundle: ServiceBundle = ServiceBundle(
                template_provider=template_provider, file_writer=file_writer
            )
            service: IFileGen = bundle.service or FileGen(component_bundle=service_bundle)

            # Setting up CLI command strategies
            commands = [GenConfigCommand()]

            # Setting up primary adapter (CLI interface)
            cli_bundle: CLIBundle = CLIBundle(service=service, parser=parser, commands=commands)
            self._cli: ICLI = bundle.cli or CLI(component_bundle=cli_bundle)

            # Mark as initialized
            self._is_initialized = True

        except (TypeError, ValueError) as exc:
            print(f"${project_name}: {exc}")

    def run(self) -> None:
        '''
            Starts the CLI adapter to run the generator command.

            :exceptions: SystemExit, OSError
        '''
        if self._is_initialized:
            self._cli.run()
        else:
            print("${project_name}: ${project_name_camel} engine is not initialized")
