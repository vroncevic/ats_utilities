# -*- coding: UTF-8 -*-

'''
Module
    file_writer.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines local file writer adapter implementing IFileWriter.
'''

from os import makedirs
from os.path import dirname
from ats_utilities.factory_class import format_instance_to_string
from ${project_name}.domain.ports.ifile_writer import IFileWriter

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


class FileWriter(IFileWriter):
    '''
        Adapter that writes content to files on the local filesystem.

        It defines:

            :attributes: None
            :methods:
                | write_file - Writes content to the local file, creating parent directories.
                | is_initialized - Checks if the file writer component is initialized.
                | __str__ - Returns the file writer as string representation.
    '''

    def write_file(self, filename: str, content: str) -> None:
        '''
            Writes content to a local file, creating parent directories if needed.

            :param filename: The destination file path.
            :type filename: <str>
            :param content: The text content to write.
            :type content: <str>
            :exceptions: OSError.
        '''
        parent_dir = dirname(filename)

        if parent_dir:
            makedirs(parent_dir, exist_ok=True)

        with open(filename, "w", encoding="utf-8") as f:
            f.write(content)

    def is_initialized(self) -> bool:
        '''
            Checks if the file writer component is initialized.

            :return: True (success) | False (fail).
            :rtype: <bool>
            :exceptions: None.
        '''
        return True

    def __str__(self) -> str:
        '''
            Returns the file writer as string representation.

            :return: The file writer as string representation.
            :rtype: <str>
            :exceptions: None.
        '''
        return format_instance_to_string(self)
