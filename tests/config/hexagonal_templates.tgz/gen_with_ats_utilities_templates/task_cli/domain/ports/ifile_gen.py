# -*- coding: UTF-8 -*-

'''
Module
    ifile_gen.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines abstract interface for file generation.
'''

from abc import ABC, abstractmethod

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


class IFileGen(ABC):
    '''
        Abstract interface for file generation.

        It defines:

            :attributes: None
            :methods:
                | execute - Generates and writes files.
                | is_initialized - Checks if the file generator component is initialized.
                | __str__ - Returns the file generator as string representation.
    '''

    @abstractmethod
    def execute(self, template_name: str, target_filename: str, cli_params: dict) -> None:
        '''
            Generates a file from a template and writes it to target path.

            :param template_name: The name of the template to use.
            :type template_name: <str>
            :param target_filename: The output filename/path.
            :type target_filename: <str>
            :param cli_params: Parameters for template formatting.
            :type cli_params: <dict>
            :exceptions: None.
        '''
        pass

    @abstractmethod
    def is_initialized(self) -> bool:
        '''
            Checks if the file generator component is initialized.

            :return: True (success) | False (fail).
            :rtype: <bool>
            :exceptions: None.
        '''
        pass

    @abstractmethod
    def __str__(self) -> str:
        '''
            Returns the file generator as string representation.

            :return: The file generator as string representation.
            :rtype: <str>
            :exceptions: None.
        '''
        pass
