# -*- coding: UTF-8 -*-

'''
Module
    service_bundle.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines a ServiceBundle bundle for the application service.
'''

from typing import Any
from dataclasses import dataclass
from ${project_name}.domain.ports.itemplate_provider import ITemplateProvider
from ${project_name}.domain.ports.ifile_writer import IFileWriter

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


@dataclass
class ServiceBundle:
    '''
        ServiceBundle holding adapters required by the service.

        It defines:

            :attributes:
                | template_provider - Adapter for providing raw templates (default None).
                | file_writer - Adapter for writing files (default None).
            :methods:
                | validate - Validates that bundle is valid.
                | merge - Merges non-None values from another bundle.
                | to_dict - Converts the bundle attributes to a dictionary.
    '''

    template_provider: ITemplateProvider | None = None
    file_writer: IFileWriter | None = None

    def validate(self) -> None:
        '''
            Validates that bundle is valid.

            :exceptions: ValueError.
                | Template provider must be provided.
                | File writer must be provided.
        '''
        if self.template_provider is None:
            raise ValueError("Template provider must be provided.")

        if self.file_writer is None:
            raise ValueError("File writer must be provided.")

    def merge(self, other: 'ServiceBundle') -> None:
        '''
            Merges non-None values from another bundle into this one.

            :param other: Another bundle to merge into this one.
            :type other: <ServiceBundle>
            :exceptions: None.
        '''
        for field_name in self.__dataclass_fields__:
            other_value = getattr(other, field_name)

            if other_value is not None:
                setattr(self, field_name, other_value)

    def to_dict(self) -> dict[str, Any]:
        '''
            Converts the bundle attributes to a dictionary.

            :return: Dictionary representation of the bundle attributes.
            :rtype: <dict<str, Any>>
            :exceptions: None.
        '''
        return {
            name: value
            for name, value in self.__dict__.items()
            if not name.startswith('_')
        }
