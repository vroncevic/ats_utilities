# -*- coding: UTF-8 -*-

'''
Module
    iarg_parser.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines abstract interface for parsing command line arguments.
'''

from abc import ABC, abstractmethod
from typing import Any
from ${project_name}.infrastructure.icli_command import ICLICommand

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


class IArgParser(ABC):
    '''
        Abstract interface for command-line argument parser.

        It defines:

            :attributes: None
            :methods:
                | register_commands - Registers a list of ICLICommand strategies.
                | parse - Parses CLI arguments.
    '''

    @abstractmethod
    def register_commands(self, commands: list[ICLICommand]) -> None:
        '''
            Registers commands to be parsed.

            :param commands: List of commands.
            :type commands: <list[ICLICommand]>
            :exceptions: None.
        '''
        pass

    @abstractmethod
    def parse(self) -> tuple[str, dict[str, Any]]:
        '''
            Parses CLI arguments.

            :return: Tuple containing command name and parsed parameters.
            :rtype: <tuple[str, dict[str, Any]]>
            :exceptions: None.
        '''
        pass
