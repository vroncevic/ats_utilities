# -*- coding: UTF-8 -*-

'''
Module
    gen_service_command.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines GenServiceCommand class implementing ICLICommand strategy.
'''

from typing import Any
from ${project_name}.infrastructure.icli_command import ICLICommand
from ${project_name}.infrastructure.command_option import CommandOption
from ${project_name}.domain.ports.ifile_gen import IFileGen

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


class GenServiceCommand(ICLICommand):
    '''
        CLI subcommand for generating Python service classes.

        It defines:

            :attributes: None
            :methods:
                | name - Returns command name.
                | help_text - Returns help text description.
                | options - Returns list of command options.
                | execute - Orchestrates service class generation.
    '''

    @property
    def name(self) -> str:
        '''
            Returns the command name key.

            :return: The command name key.
            :rtype: <str>
            :exceptions: None.
        '''
        return "generate-service"

    @property
    def help_text(self) -> str:
        '''
            Returns the command help text.

            :return: The command help text.
            :rtype: <str>
            :exceptions: None.
        '''
        return "Generate Python service class"

    @property
    def options(self) -> list[CommandOption]:
        '''
            Returns the command options.

            :return: List of command options.
            :rtype: <list[CommandOption]>
            :exceptions: None.
        '''
        return [
            CommandOption(
                name="--filename",
                help_text="Output filename",
                default="my_service.py"
            ),
            CommandOption(
                name="--module-name",
                help_text="Module/class name (PascalCase)",
                required=True
            ),
            CommandOption(
                name="--app-name",
                help_text="Root application name",
                required=True
            )
        ]

    def execute(self, params: dict[str, Any], service: IFileGen) -> None:
        '''
            Executes the service class generation logic.

            :param params: Subcommand parameters from CLI parser.
            :type params: <dict[str, Any]>
            :param service: Generation orchestrator service instance.
            :type service: <IFileGen>
            :exceptions: None.
        '''
        target_filename = params.pop("filename")

        service.execute(
            template_name="service",
            target_filename=target_filename,
            cli_params=params
        )
        print(f"✅ Service class successfully created: {target_filename}")
