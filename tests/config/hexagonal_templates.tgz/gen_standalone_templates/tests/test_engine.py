# -*- coding: UTF-8 -*-

'''
Module
    test_engine.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Unit tests for main engine (${project_name_camel}).
'''

import unittest
from unittest.mock import MagicMock, patch
from typing import Any
from ${project_name}.i${project_name} import I${project_name_camel}
from ${project_name}.engine import ${project_name_camel}
from ${project_name}.${project_name}_bundle import ${project_name_camel}Bundle
from ${project_name}.domain.ports.itemplate_provider import ITemplateProvider
from ${project_name}.domain.ports.ifile_writer import IFileWriter
from ${project_name}.domain.ports.ifile_gen import IFileGen
from ${project_name}.infrastructure.iarg_parser import IArgParser
from ${project_name}.infrastructure.icli import ICLI

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


class TestEngine(unittest.TestCase):
    '''
        Defines engine unit tests.

        It defines:

            :attributes: None
            :methods:
                | test_default_init - Tests default constructor initialization.
                | test_custom_injection - Tests custom dependency injection in ${project_name_camel}.
                | test_init_failure - Tests engine behavior when dependency initialization fails.
                | test_run_success - Tests that run() executes CLI if initialized.
                | test_run_failure - Tests that run() prints error and does not execute if uninitialized.
                | test_${project_name}_bundle_helpers - Tests ${project_name_camel}Bundle helpers.
    '''

    def test_default_init(self) -> None:
        '''
            Tests default constructor initialization of ${project_name_camel}.

            :exceptions: None.
        '''
        engine: I${project_name_camel} = ${project_name_camel}()
        self.assertTrue(engine.is_initialized())

    def test_custom_injection(self) -> None:
        '''
            Tests custom dependency injection in ${project_name_camel} constructor.

            :exceptions: None.
        '''
        mock_provider: MagicMock = MagicMock(spec=ITemplateProvider)
        mock_writer: MagicMock = MagicMock(spec=IFileWriter)
        mock_service: MagicMock = MagicMock(spec=IFileGen)
        mock_parser: MagicMock = MagicMock(spec=IArgParser)
        mock_cli: MagicMock = MagicMock(spec=ICLI)

        bundle: ${project_name_camel}Bundle = ${project_name_camel}Bundle(
            template_provider=mock_provider,
            file_writer=mock_writer,
            service=mock_service,
            parser=mock_parser,
            cli=mock_cli
        )

        engine: I${project_name_camel} = ${project_name_camel}(bundle)
        self.assertTrue(engine.is_initialized())

    def test_init_failure(self) -> None:
        '''
            Tests engine behavior when dependency initialization fails.

            :exceptions: None.
        '''
        with patch('${project_name}.engine.FileGen', side_effect=ValueError("service initialization failed.")):
            with patch('builtins.print') as mock_print:
                engine: I${project_name_camel} = ${project_name_camel}()
                self.assertFalse(engine.is_initialized())
                mock_print.assert_called_with("${project_name}: service initialization failed.")

    def test_run_failure_with_unexpected_exception(self) -> None:
        '''
            Tests that run() prints error and does not execute if unexpected exception.

            :exceptions: None.
        '''
        with patch('${project_name}.engine.FileGen', side_effect=RuntimeError("unexpected error.")):
            with patch('builtins.print') as mock_print:
                engine: I${project_name_camel} = ${project_name_camel}()
                engine.run()
                mock_print.assert_any_call("${project_name} unexpected exception: unexpected error.")

    def test_run_success(self) -> None:
        '''
            Tests that run() executes CLI if initialized.

            :exceptions: None.
        '''
        mock_cli: MagicMock = MagicMock(spec=ICLI)
        bundle: ${project_name_camel}Bundle = ${project_name_camel}Bundle(cli=mock_cli)

        engine: I${project_name_camel} = ${project_name_camel}(bundle)
        self.assertTrue(engine.is_initialized())
        engine.run()
        mock_cli.run.assert_called_once()

    def test_run_failure(self) -> None:
        '''
            Tests that run() prints error and does not execute if uninitialized.

            :exceptions: None.
        '''
        with patch('${project_name}.engine.FileGen', side_effect=ValueError("service initialization failed.")):
            with patch('builtins.print') as mock_print:
                engine: I${project_name_camel} = ${project_name_camel}()
                self.assertFalse(engine.is_initialized())
                engine.run()
                mock_print.assert_any_call("${project_name}: service initialization failed.")
                mock_print.assert_any_call("${project_name}: engine is not initialized.")

    def test_${project_name}_bundle_helpers(self) -> None:
        '''
            Tests ${project_name_camel}Bundle merge and to_dict helpers.

            :exceptions: None.
        '''
        provider1: MagicMock = MagicMock(spec=ITemplateProvider)
        writer1: MagicMock = MagicMock(spec=IFileWriter)
        service1: MagicMock = MagicMock(spec=IFileGen)
        parser1: MagicMock = MagicMock(spec=IArgParser)
        cli1: MagicMock = MagicMock(spec=ICLI)

        bundle1: ${project_name_camel}Bundle = ${project_name_camel}Bundle(template_provider=provider1, file_writer=None)
        bundle2: ${project_name_camel}Bundle = ${project_name_camel}Bundle(template_provider=None, file_writer=writer1)
        bundle1.merge(bundle2)

        self.assertEqual(bundle1.template_provider, provider1)
        self.assertEqual(bundle1.file_writer, writer1)

        d: dict[str, Any] = bundle1.to_dict()
        self.assertEqual(d["template_provider"], provider1)
        self.assertEqual(d["file_writer"], writer1)

        bundle3: ${project_name_camel}Bundle = ${project_name_camel}Bundle(
            template_provider=None, file_writer=writer1, parser=parser1, service=service1, cli=cli1
        )

        with self.assertRaises(ValueError):
            bundle3.validate()

        bundle4: ${project_name_camel}Bundle = ${project_name_camel}Bundle(
            template_provider=provider1, file_writer=None, parser=parser1, service=service1, cli=cli1
        )

        with self.assertRaises(ValueError):
            bundle4.validate()

        bundle5: ${project_name_camel}Bundle = ${project_name_camel}Bundle(
            template_provider=provider1, file_writer=writer1, parser=None, service=service1, cli=cli1
        )

        with self.assertRaises(ValueError):
            bundle5.validate()

        bundle6: ${project_name_camel}Bundle = ${project_name_camel}Bundle(
            template_provider=provider1, file_writer=writer1, parser=parser1, service=None, cli=cli1
        )

        with self.assertRaises(ValueError):
            bundle6.validate()

        bundle7: ${project_name_camel}Bundle = ${project_name_camel}Bundle(
            template_provider=provider1, file_writer=writer1, parser=parser1, service=service1, cli=None
        )

        with self.assertRaises(ValueError):
            bundle7.validate()
