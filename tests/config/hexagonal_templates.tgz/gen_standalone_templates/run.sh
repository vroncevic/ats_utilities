
python3 main.py generate-config --app-name "AtsSistem" --env dev --db-host "10.0.0.15" --filename "generated/configs/test_config.ini"
python3 main.py generate-service --module-name "Auth" --app-name "AtsSistem" --filename "generated/services/auth_service.py"
