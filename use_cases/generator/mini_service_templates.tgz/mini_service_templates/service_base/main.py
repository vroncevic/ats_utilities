# -*- coding: UTF-8 -*-

from ${service_name}.server import ${service_name_camel}Server

def main():
    server = ${service_name_camel}Server(port=8080)
    server.run()

if __name__ == '__main__':
    main()
