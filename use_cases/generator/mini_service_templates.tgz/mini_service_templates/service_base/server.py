# -*- coding: UTF-8 -*-

class ${service_name_camel}Server:
    def __init__(self, port: int) -> None:
        self.port = port
        self.name = "${service_name}"

    def run(self) -> None:
        print(f"Server {self.name} listening on port {self.port}...")
